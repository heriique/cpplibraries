#include "drawable.h"

Drawable::Drawable()
{
}
