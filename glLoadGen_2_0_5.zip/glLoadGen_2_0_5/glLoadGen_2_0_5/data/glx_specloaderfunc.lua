local util = require "util"

return assert(dofile(util.GetDataFilePath() .. "gl_specloaderfunc.lua"))
