--Initialization text for the 'glX' spec header.

return {}
