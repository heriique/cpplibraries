function RandomFloat(min, max) {
  return min + (max - min) * Math.random();
}
