#import <UIKit/UIKit.h>

@interface FGAppDelegate : UIResponder <UIApplicationDelegate>

@property (copy, readonly) NSArray *windows;

@end
